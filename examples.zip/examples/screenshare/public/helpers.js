'use strict';

const Video = require('twilio-video');

/**
 * Create a LocalVideoTrack for your screen. You can then share it
 * with other Participants in the Room.
 * @param {number} height - Desired vertical resolution in pixels
 * @param {number} width - Desired horizontal resolution in pixels
 * @returns {Promise<LocalVideoTrack>}
 */
function createScreenTrack(height, width) {

  /*
  if (typeof navigator === 'undefined'
    || !navigator.mediaDevices
    || !navigator.mediaDevices.getDisplayMedia) {
      window.alert("errr1");
    return Promise.reject(new Error('getDisplayMedia is not supported'));
  }
  window.alert("errr2");
  return navigator.mediaDevices.getDisplayMedia({
    video: {
      height: height,
      width: width
    }
  }).then(function(stream) {
    window.alert("errr3");
    return new Video.LocalVideoTrack(stream.getVideoTracks()[0]);
  });*/
}

exports.createScreenTrack = createScreenTrack;
